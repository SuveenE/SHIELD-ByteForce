from flask import Flask, render_template, request
import pickle
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer

# Using Tokenizer

def sanitization(web):                      # tokenizing method
    web = web.lower()
    token = []
    dot_token_slash = []
    raw_slash = str(web).split('/')
    for i in raw_slash:
        raw1 = str(i).split('-')            # removing slash to get token
        slash_token = []
        for j in range(0,len(raw1)):
            raw2 = str(raw1[j]).split('.')  # removing dot to get the tokens
            slash_token = slash_token + raw2
        dot_token_slash = dot_token_slash + raw1 + slash_token # all tokens
    token = list(set(dot_token_slash))      # to remove same words
    if 'com' in token:
        token.remove('com')                 # remove com
    return token
# Store vectors into X variable as Our XFeatures


# Using Tokenizer

# Store vectors into X variable as Our XFeatures
def word_divide_char(inputs):
    characters=[]
    for i in inputs:
        characters.append(i)
    return characters


model_0 = pickle.load(open('model_0.pkl', 'rb'))
model_1 = pickle.load(open('model_1.pkl', 'rb'))

vectorizer=pickle.load(open('vectorizer.pkl', 'rb'))
tranformword=pickle.load(open('tranformword.pkl', 'rb'))

app = Flask(__name__)

@app.route('/index1.html')
def runURLCheck():
    return render_template('index1.html')

@app.route('/index2.html')
def runPasswordCheck():
    return render_template('index2.html')

@app.route('/')
def man():
    return render_template('Home.html')

@app.route('/predict1', methods=['POST'])
def home1():
    data1 = request.form['a']
    data1=[data1]
    print(data1)
    data1= vectorizer.transform(data1)
    pred = model_0.predict(data1)
    print(pred)
    return render_template('after.html', data=pred)


@app.route('/predict2', methods=['POST'])
def home2():
    data2 = request.form['b']
    data2=[data2]
    print(data2)
    data2= tranformword.transform(data2)
    pred = model_1.predict(data2)
    print(pred)
    return render_template('after1.html', data=pred)

if __name__ == "__main__":
    app.run(debug=True)
